<?php


/**
 * This file contains the moodle hooks for the submission helixassign plugin
 *
 * @package   assignsubmission_helixassign
 * @copyright Streaming LTD 2013
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();

define('SUBMISSION_HELIXMEDIA_MIN_VERSION', 2014111701);
