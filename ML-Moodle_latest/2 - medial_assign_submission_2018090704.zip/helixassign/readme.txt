This is the MEDIAL submission plugin for Moodle 2.x.

Installation
------------

1 - Check that you have the MEDIAL Activity module installed on your system. If it is not installed,
    please install before proceeding.
2 - Copy the contents of the zip file which contains this readme.txt into the moodle/mod/assign/submission
    directory of your Moodle installation.
3 - Login to your Moodle system as an administrator.
4 - Click the "Notifications" link in the "Administration" block.
5 - Follow the on-screen instructions.


Module provided by Streaming LTD http://www.streaming.co.uk
